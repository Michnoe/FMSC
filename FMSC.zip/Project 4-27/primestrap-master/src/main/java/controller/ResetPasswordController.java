/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.LoginDAO;
import dao.LoginDAOImpl;
import dao.ResetPasswordDAOImpl;

import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import model.SessionBean;
import model.LoginBean;
import model.ResetPasswordBean;




/**
 *
 * @author Mike
 */
@ManagedBean
@RequestScoped
public class ResetPasswordController {


    private String response = "";
    private ResetPasswordBean aResetPasswordBean;
    
   
    /**
     * Creates a new instance of LoginController
     */
    public ResetPasswordController() {
    	setaResetPasswordBean(new ResetPasswordBean()); 
    }

  
    public String getResponse() {
       
        return response;
    }

    /**
     * @param response the response to set
     */
    public void setResponse(String response) {
        this.response = response;
    }

    
    public String resetPassword(){
    	ResetPasswordDAOImpl aResetPassword = new ResetPasswordDAOImpl();
    	boolean emailExist = aResetPassword.checkEmail(getaResetPasswordBean());
    	if(emailExist == true)
    	{
    		aResetPassword.setPassword(getaResetPasswordBean());
    		aResetPassword.sendEmail(getaResetPasswordBean());
    		response = "Your Password has been resetted!";
    		response += "<br/> Please Check your email!";
    		setResponse(response);
    		return "";
    	}
    	else
    	{
    		response = "Email Doesn't exists!";
    		setResponse(response);
    		return "";
    	}
    	
    }


	public ResetPasswordBean getaResetPasswordBean() {
		return aResetPasswordBean;
	}


	public void setaResetPasswordBean(ResetPasswordBean aResetPasswordBean) {
		this.aResetPasswordBean = aResetPasswordBean;
	}
    
 
    


}
