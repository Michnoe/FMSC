/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;

import model.LoginBean;
import model.SignUpBean;

/**
 *
 * @author it3530105
 */
public interface LoginDAO {
 
    public int findByName(String userid, String passwd); // either get one back or several if multiple same name allowed  
    
}