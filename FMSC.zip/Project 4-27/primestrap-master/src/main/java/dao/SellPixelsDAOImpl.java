/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.PixelBean;
import model.SellPixelsBean;

/**
 *
 * @author it3530105
 */
public class SellPixelsDAOImpl {
    int pid;
    
    public SellPixelsDAOImpl(){
    pid=10;
    }
    
    public int checkPixelsAvailability(ArrayList<PixelBean> pixelsData,SellPixelsBean aSellPixelsBean) {
        int [][] virtual_view = new int[1200][1200];
        for (int i = 0; i < pixelsData.size(); i++) {
            int x1 = pixelsData.get(i).getCoord_x1();
            int x2 = pixelsData.get(i).getCoord_y1();
            int y1 = pixelsData.get(i).getCoord_x2();
            int y2 = pixelsData.get(i).getCoord_y2();

            for (int j = y1; j <= y2; j++) {
                for (int k = x1; k <= x2; k++) {
                    virtual_view[j][k]=1;   
                }
            }

        }
        // check availability
        int flag = 1;
        for (int j = aSellPixelsBean.getY1(); j <= aSellPixelsBean.getY2(); j++) {
                for (int k = aSellPixelsBean.getX1(); k <= aSellPixelsBean.getX2(); k++) {
                    if(virtual_view[j][k] == 1){
                    flag = 0;
                    }
                }
            }
        
        return flag;
    }
    public int confirmSellPixel(SellPixelsBean aSellPixelsBean){
    int rowCount = 0;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
            System.exit(0);
        }

        try {
        	String filename = "C:/Users/super/Documents/Project353.accdb";
            String myDB = "jdbc:ucanaccess://"+ filename +";memory=false\";";
            Connection DBConn = DriverManager.getConnection(myDB, "", "");

            String insertString;
            Statement stmt = DBConn.createStatement();
            
            insertString = "INSERT INTO PIXELS (coord_x1,coord_y1,coord_x2,coord_y2,title,website) VALUES ("
                   
                    + aSellPixelsBean.getX1()
                    + "," + aSellPixelsBean.getY1()
                    + "," + aSellPixelsBean.getX2()
                    + "," + aSellPixelsBean.getY2()
                    + ",'" + aSellPixelsBean.getTitle()
                    + "','" + aSellPixelsBean.getWebsite()
                    + "')";
            
            rowCount = stmt.executeUpdate(insertString);
            System.out.println("insert string =" + insertString);
            DBConn.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return rowCount;
    
    }
}
