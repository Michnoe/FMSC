/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.GenerateImageDAOImpl;
import dao.SellPixelsDAOImpl;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.servlet.http.HttpSession;
import model.SellPixelsBean;
import model.SessionBean;

/**
 *
 * @author it3530105
 */
@ManagedBean
@SessionScoped
public class SellPixelsFormController {
    private SellPixelsBean aSellPixelsBean;
    private String response= "";
    private Double cost;
    /**
     * Creates a new instance of SellPixelsFormController
     */
    public SellPixelsFormController() {
        aSellPixelsBean = new SellPixelsBean();
    }

    public String sellPixels() {
        HttpSession session = SessionBean.getSession();
        
        GenerateImageDAOImpl aProductImageDAO = new GenerateImageDAOImpl();
        ArrayList result = aProductImageDAO.createView();
        SellPixelsDAOImpl sellpixels = new SellPixelsDAOImpl();
        int flag = sellpixels.checkPixelsAvailability(result, aSellPixelsBean);
        if(flag == 0){
            setResponse("Invalid Pixels");
            System.out.println("Invalid Pixels");
            session.setAttribute("sell_response", "Invalid Pixels");
           return "pixelsReply.xhtml?faces-redirect=true" ;
        }
        else if(flag == 1){
            setResponse("Valid Pixels");
            System.out.println("Valid Pixels");
            
            int rowcount=sellpixels.confirmSellPixel(aSellPixelsBean);
            if(rowcount !=0)
            {
            setResponse("Valid Pixels <br/> You have successfully bought the pixels!!");
            System.out.println("Valid Pixels");
            session.setAttribute("sell_response", "Valid Pixels <br/> You have successfully bought the pixels!!");
            return "pixelsReply_1.xhtml?faces-redirect=true" ;
            }
            else{
                setResponse("Valid Pixels <br/> but not able to insert into database!!");
                session.setAttribute("sell_response", "Valid Pixels <br/> but not able to insert into database!!");
                System.out.println("Valid Pixels but not able to insert into database");
                return "pixelsReply.xhtml?faces-redirect=true" ;
            }
            
        }
        else{
            return "invalid" ;
        }
        
    }

    /**
     * @return the response
     */
    public String getResponse() {
        HttpSession session = SessionBean.getSession();
        String temp = (String)session.getAttribute("sell_response");
        return temp;
    }

    /**
     * @param response the response to set
     */
    public void setResponse(String response) {
        this.response = response;
    }

    /**
     * @return the aSellPixelsBean
     */
    public SellPixelsBean getaSellPixelsBean() {
        return aSellPixelsBean;
    }

    /**
     * @param aSellPixelsBean the aSellPixelsBean to set
     */
    public void setaSellPixelsBean(SellPixelsBean aSellPixelsBean) {
        this.aSellPixelsBean = aSellPixelsBean;
    }

    /**
     * @return the cost
     */
    public Double getCost() {
        return cost;
    }

    /**
     * @param cost the cost to set
     */
    public void setCost(Double cost) {
        this.cost = cost;
    }

    
}
