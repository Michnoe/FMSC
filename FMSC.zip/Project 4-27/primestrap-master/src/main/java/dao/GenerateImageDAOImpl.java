/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import model.PixelBean;

/**
 *
 * @author it3530105
 */
public class GenerateImageDAOImpl {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public ArrayList<PixelBean> createView() {
        ArrayList<PixelBean> aPixelBeanCollection = new ArrayList<PixelBean>();
        
        Connection conn = null;
        try {
           DBHelper.loadDriver("net.ucanaccess.jdbc.UcanaccessDriver");
            // if doing the above in Oracle: DBHelper.loadDriver("oracle.jdbc.driver.OracleDriver");
            
            String filename = "C:/Users/super/Documents/Project353.accdb";//use the name of your database!
            
            String myDB = "jdbc:ucanaccess://"+ filename +";memory=false";
            //String myDB = "jdbc:mysql://project353.cvzlvgeblu4c.us-east-1.rds.amazonaws.com:3306/Project353";
            // if doing the above in Oracle:  String myDB = "jdbc:oracle:thin:@oracle.itk.ilstu.edu:1521:ora478";
            
            conn = DriverManager.getConnection(myDB,"",""); 

            String query = "SELECT * FROM PIXELS";
            int id;
			String title, website;
            int coord_x1, coord_y1, coord_x2, coord_y2;
            PixelBean aPixelBean;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            while (rs.next()) {
                id = rs.getInt("id");
                coord_x1 = rs.getInt("coord_x1");
                coord_y1 = rs.getInt("coord_y1");
                coord_x2 = rs.getInt("coord_x2");
                coord_y2 = rs.getInt("coord_y2");
                title = rs.getString("title");
                website = rs.getString("website");

                // make a ProfileBean object out of the values
                aPixelBean = new PixelBean(id, coord_x1, coord_y1, coord_x2, coord_y2, title, website);
                // add the newly created object to the collection
                aPixelBeanCollection.add(aPixelBean);
            }
         System.out.println("Size = " + aPixelBeanCollection.size());
            rs.close();
            stmt.close();
        } catch (Exception e) {
            System.err.println("ERROR: Problems with SQL select");
            e.printStackTrace();
        }
        try {
            conn.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return aPixelBeanCollection;
    }

}
