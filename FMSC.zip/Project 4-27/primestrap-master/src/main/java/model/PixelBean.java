/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author it3530105
 */
public class PixelBean {
    private int id;
    private int coord_x1;
    private int coord_x2;
    private int coord_y1;
    private int coord_y2;
    private String title;
    private String website;
    
    public PixelBean(){
    }
    
    public PixelBean(int id2, int coord_x1, int coord_y1, int coord_x2, int coord_y2, String title, String website){
    this.id = id2;
    this.coord_x1 = coord_x1;
    this.coord_y1 = coord_x2;
    this.coord_x2 = coord_y1;
    this.coord_y2 = coord_y2;
    this.title = title;
    this.website = website;
    }

    /**
     * @return the coord_x1
     */
    public int getCoord_x1() {
        return coord_x1;
    }

    /**
     * @param coord_x1 the coord_x1 to set
     */
    public void setCoord_x1(int coord_x1) {
        this.coord_x1 = coord_x1;
    }

    /**
     * @return the coord_x2
     */
    public int getCoord_x2() {
        return coord_x2;
    }

    /**
     * @param coord_x2 the coord_x2 to set
     */
    public void setCoord_x2(int coord_x2) {
        this.coord_x2 = coord_x2;
    }

    /**
     * @return the coord_y1
     */
    public int getCoord_y1() {
        return coord_y1;
    }

    /**
     * @param coord_y1 the coord_y1 to set
     */
    public void setCoord_y1(int coord_y1) {
        this.coord_y1 = coord_y1;
    }

    /**
     * @return the coord_y2
     */
    public int getCoord_y2() {
        return coord_y2;
    }

    /**
     * @param coord_y2 the coord_y2 to set
     */
    public void setCoord_y2(int coord_y2) {
        this.coord_y2 = coord_y2;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the website
     */
    public String getWebsite() {
        return website;
    }

    /**
     * @param website the website to set
     */
    public void setWebsite(String website) {
        this.website = website;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    
    
    
}
