/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.ArrayList;
import model.UpdateProfileBean;

/**
 *
 * @author admin
 */
public interface UpdateProfileDAO {
    
    public ArrayList findByName(String aName); // either get one back or several if multiple same name allowed  
    public int updateProfile(UpdateProfileBean pro);

    
}
