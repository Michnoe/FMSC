/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;



import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import javax.faces.bean.ManagedBean;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import model.EmailBean;

import model.LoginBean;

/**
 *
 * @author Mike
 * 
 * Handles signing up for the Mailing List
 */
@ManagedBean

public class MailingController {

  // This corresponds to the response to be sent back to the client    
  private EmailBean theModel;
  private String mailStatus;
  private String removeStatus;

  /**
   * Creates a new instance of ProfileController
   */
  public MailingController() {
    theModel = new EmailBean();
//        UserBean theUser = (UserBean) FacesContext.getCurrentInstance().getExternalContext().getApplicationMap().get("theUser");
//        theModel.setFirstName(theUser.getFirstName());
//        theModel.setLastName(theUser.getLastName());
  }

  public void addToMailList() {
    SubscribeMailingList aProfileDAO = new SubscribeMailingList();    // Creating a new object each time.
    int status = aProfileDAO.createProfile(getTheModel()); // Doing anything with the object after this?
    if (status != 0) {
      setMailStatus("You are subcribed to email alerts!");
    } else {
      setMailStatus("That email already is a subscriber");
    }
  }

  public void removeFromMailList() {
	  SubscribeMailingList aSubscribeMailingList = new SubscribeMailingList();    // Creating a new object each time.
    int status = aSubscribeMailingList.removeProfile(getTheModel()); // Doing anything with the object after this?
    if (status != 0) {
      setRemoveStatus("You are removed from the mailing list!");
    } else {
      setRemoveStatus("Email unsubscription failed!");
    }
  }

  public String homePage() {
    return "home.xhtml";
  }

  /**
   * @return the theModel
   */
  public EmailBean getTheModel() {
    return theModel;
  }

  /**
   * @param theModel the theModel to set
   */
  public void setTheModel(EmailBean mailBean) {
    this.theModel = mailBean;
  }

  /**
   * @return the mailStatus
   */
  public String getMailStatus() {
    return mailStatus;
  }

  /**
   * @param mailStatus the mailStatus to set
   */
  public void setMailStatus(String mailStatus) {
    this.mailStatus = mailStatus;
  }

  /**
   * @return the removeStatus
   */
  public String getRemoveStatus() {
    return removeStatus;
  }

  /**
   * @param removeStatus the removeStatus to set
   */
  public void setRemoveStatus(String removeStatus) {
    this.removeStatus = removeStatus;
  }

}
