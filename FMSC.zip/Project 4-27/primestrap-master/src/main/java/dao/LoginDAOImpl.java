/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import model.LoginBean;



/**
 *
 * @author it3530105
 */
public class LoginDAOImpl implements LoginDAO{
    private int selectProfilesFromDB(String query) {
        int rowCount = 0;
        
        Connection DBConn = null;
        try {
        	
        	
        	DBHelper.loadDriver("net.ucanaccess.jdbc.UcanaccessDriver");
            // if doing the above in Oracle: DBHelper.loadDriver("oracle.jdbc.driver.OracleDriver");
            
            String filename = "C:/Users/super/Documents/Project353.accdb";//use the name of your database!
            
            String myDB = "jdbc:ucanaccess://"+ filename +";memory=false";
            DBConn = DriverManager.getConnection(myDB, "", "");
            // With the connection made, create a statement to talk to the DB server.
            // Create a SQL statement to query, retrieve the rows one by one (by going to the
            // columns), and formulate the result string to send back to the client.
            Statement stmt = DBConn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            if(rs.next()) {
               rowCount = 1;

            }
            rs.close();
            stmt.close();
        } catch (Exception e) {
            System.err.println("ERROR: Problems with SQL select");
            e.printStackTrace();
        } 
        try {
            DBConn.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return rowCount;
    }
   
    @Override
    public int findByName(String username, String password) {
        int flag;
        // if interested in matching wild cards, use: LIKE and '%" + aName + "%'";
        String query = "SELECT * FROM LoginInfo ";
        query += "WHERE userid = '" + username + "'";
        query += " and password ='" + password + "'";

        flag  = selectProfilesFromDB(query);
        
        
        return flag;
    }
    
}
