/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import org.primefaces.event.FileUploadEvent;
/**
 *
 * @author super
 */
@ManagedBean(name = "EmailBean")
@RequestScoped

public class EmailBean {
  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




/**
 *
 * @author super
 */



  private String email;
  private String keywords;

  public EmailBean() {

  }

  public EmailBean(String email) {
    this.email = email;
    this.keywords = keywords;

  }

  /**
   * @return the email
   */
  public String getMail() {
    return email;
  }

  /**
   * @param email the email to set
   */
  public void setMail(String email) {
    this.email = email;
  }

  /**
   * @return the keywords
   */
}
