/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.LoginDAO;
import dao.LoginDAOImpl;

import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import model.SessionBean;
import model.LoginBean;




/**
 *
 * @author Mike
 */
@ManagedBean
@SessionScoped
public class LoginController {

    private static int count = 0;
    private LoginBean loginModel;
    private String response;
    private String sameuser;
    
    
    /**
     * Creates a new instance of LoginController
     */
    public LoginController() {
        loginModel = new LoginBean();
        count = 1;
        HttpSession session = SessionBean.getSession();
       
        try{
        	 session.setAttribute("count", count);
            }
            catch(NullPointerException npe){
            	System.out.println("NUll pinter exception for session, IT's Normal in first time!");
            	
            }
    }

    public String checkLogin() {
        LoginDAO aLoginDAO = new LoginDAOImpl();
        int rowCount = aLoginDAO.findByName(loginModel.getUsername(), loginModel.getPassword());
        if (rowCount == 1) {
        HttpSession session = SessionBean.getSession();
               session.setAttribute("userid", loginModel.getUsername());
               
               setResponse(loginModel.getUsername());
               return "homepage.xhtml?faces-redirect=true";
        }
        else
        {
        	
        	return "LoginBad.xhtml?faces-redirect=true";
        }
  }
    

    /**
     * @return the loginModel
     */
    public LoginBean getLoginModel() {
        return loginModel;
    }

    /**
     * @param loginModel the loginModel to set
     */
    public void setLoginModel(LoginBean loginModel) {
        this.loginModel = loginModel;
    }

    /**
     * @return the response
     */
    public String getResponse() {
        String resultStr = "";

        
        resultStr = "Hello user: ";
        resultStr += response;
        response = resultStr;
        return response;
    }

    /**
     * @param response the response to set
     */
    public void setResponse(String response) {
        this.response = response;
    }

    
    

    


}
