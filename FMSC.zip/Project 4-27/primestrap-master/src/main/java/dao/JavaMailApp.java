/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Mike
 */
import java.util.*;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.faces.context.FacesContext;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.ServletContext;

public class JavaMailApp {

    public JavaMailApp(String to, String fname, String lname, String userid,String sec_question, String sec_answer) {

        String str;

        // Sender's email ID needs to be mentioned
        String from = "manoe@ilstu.edu";

        // Assuming you are sending email from this host
        String host = "outlook.office365.com";

        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server
        properties.setProperty("mail.smtp.host", host);
        properties.setProperty("mail.smtp.starttls.enable", "true");
        properties.setProperty("mail.smtp.auth", "true");
        properties.setProperty("mail.smtp.port", "587");
        // Get the default Session object.
        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("manoe@ilstu.edu", "UiD808987608");
            }
        });

        try {
            // Create a default MimeMessage object.
            Message message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(to));

            // Set Subject: header field
            message.setSubject("JavaMailApp successful signup");

            // This mail has 2 part, the BODY and the embedded image
            MimeMultipart multipart = new MimeMultipart("related");

            // first part (the html)
            BodyPart messageBodyPart = new MimeBodyPart();
            str = "Hey " + fname + " " + lname + ",<br/>";
            str += "You have successfully signed up for the JavaMailApp.<br/>";
            str += "Registered Email is: " + to + "<br/>";
            str += "Registered Userid is: " + userid + "<br/><br/>";
            str += "Security question is: " + sec_question + "<br/>";
            str += "Security answer is: " + sec_answer + "<br/><br/>";
            str += "Thanks,<br/>JavaMailApp Team<br/>Illinois State University<br/>";
            str += "<img src=\"cid:image\">";
            messageBodyPart.setContent(str, "text/html");

            // add it
            multipart.addBodyPart(messageBodyPart);

            // second part (the image)
            messageBodyPart = new MimeBodyPart();

            //Code for handling the nullpointerexception for image
            ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance()
                    .getExternalContext().getContext();
            String realPath = ctx.getRealPath("/");

            String fileName = realPath + "/resources/images/ilstu.jpg";
             DataSource fds = new FileDataSource(fileName);
            

            messageBodyPart.setDataHandler(new DataHandler(fds));
            messageBodyPart.setHeader("Content-ID", "<image>");

            // add image to the multipart
            multipart.addBodyPart(messageBodyPart);

            // put everything together
            message.setContent(multipart);

            // Send message
            Transport.send(message);
            System.out.println("Sent message successfully!");

        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
    }
}
