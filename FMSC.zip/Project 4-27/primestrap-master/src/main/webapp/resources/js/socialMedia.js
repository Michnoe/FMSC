/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

  
   /* Replace the subdomain with your own subdomain from a Site in your OneAll account */   
  var oneall_subdomain = 'it353';
   
  /* Asynchronously load the library */
  var oa = document.createElement('script');
  oa.type = 'text/javascript'; oa.async = true;
  oa.src = '//' + oneall_subdomain + '.api.oneall.com/socialize/library.js';
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(oa, s)
    
  /* This is an event */
  var my_on_login_redirect = function(args) {
    alert("You have logged in with " + args.provider.name); 
     
    /* As this is a demo return false to cancel the redirection to the callback_uri */
    return false;
  }
    
  /* Initialise the asynchronous queue */
  var _oneall = _oneall || [];
    
  /* Social Login Example */
  _oneall.push(['social_login', 'set_providers', ['facebook', 'twitter', 'linkedin', 'google', 'yahoo', 'foursquare', 'blogger', 'github']]);
  _oneall.push(['social_login', 'set_grid_sizes', [2,2]]);
  _oneall.push(['social_login', 'set_callback_uri', 'http://www.oneall.com/callback/']);
  _oneall.push(['social_login', 'set_event', 'on_login_redirect', my_on_login_redirect ]);
  _oneall.push(['social_login', 'do_render_ui', 'social_login_demo']);
    



