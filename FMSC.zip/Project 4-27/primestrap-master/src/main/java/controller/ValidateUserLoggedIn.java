/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ComponentSystemEvent;
import javax.servlet.http.HttpSession;
import model.SessionBean;

/**
 *
 * @author it3530105
 */
@ManagedBean(name = "checkLoggedIn")
@ApplicationScoped
public class ValidateUserLoggedIn {

    public String isLoggedin(ComponentSystemEvent event) {
        String navi = null;
        String userid = "false";
        HttpSession session = SessionBean.getSession();
        
        userid = (String) session.getAttribute("userid");
        if (userid == null || userid.isEmpty()) {

            FacesContext fc = FacesContext.getCurrentInstance();
            ConfigurableNavigationHandler nav = (ConfigurableNavigationHandler) fc.getApplication().getNavigationHandler();
            nav.performNavigation("access-denied?faces-redirect=true");

//            navi = "access-denied?faces-redirect=true"; // this doesn't work! Why not? 
            // Navigation based on a method's return value is only performed by components implementing ActionSource2 interface and providing an attribute taking a MethodExpression for that, such as action attribute of UICommand components, which is queued during Apply Request Values phase and invoked during Invoke Application phase. The <f:event listener> is merely a component system event listener method, not an action method. 
            // Ref: http://stackoverflow.com/questions/16106418/how-to-perform-navigation-in-prerenderview-listener-method
            // Below is an OK alternative
//            String theURL = "faces/access-denied.xhtml"; // redirects to the access denied page
//            FacesContext faces = FacesContext.getCurrentInstance();
//            ExternalContext context = faces.getExternalContext();
//            HttpServletResponse response = (HttpServletResponse) context.getResponse();
//            try {
//                response.sendRedirect(theURL);
//                faces.responseComplete(); // need this or will get "Cannot forward after response has been committed"
//                // exception. It bypasses the Render Response phase
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
        }

        return navi;
    }

}
