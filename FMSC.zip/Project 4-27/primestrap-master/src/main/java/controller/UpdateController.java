/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;


import dao.UpdateProfileDAO;
import dao.UpdateProfileDAOImpl;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;

import javax.faces.bean.SessionScoped;
import javax.servlet.http.HttpSession;
import model.SessionBean;
import model.UpdateProfileBean;


/**
 *
 * @author admin
 */
@ManagedBean
@SessionScoped
public class UpdateController {

    // This corresponds to the response to be sent back to the client
    //public static String userid;
    private UpdateProfileBean updateProfileModel;
    private String updateStatus;

    public UpdateController() {
        updateProfileModel = new UpdateProfileBean();
    }

   
    public UpdateProfileBean getUpdateProfileModel() {
        return updateProfileModel;
    }

    public void setUpdateProfileModel(UpdateProfileBean updateProfileModel) {
        this.updateProfileModel = updateProfileModel;
    }

    public String getUpdateStatus() {
        return updateStatus;
    }

    public void setUpdateStatus(String updateStatus) {
        this.updateStatus = updateStatus;
    }

    
    public String retrieveProfile() {
        UpdateProfileDAO aUpdateProfileDAO = new UpdateProfileDAOImpl();    // Creating a new object each time.
        HttpSession session = SessionBean.getSession();
        String userid = (String) session.getAttribute("userid");
        ArrayList result = aUpdateProfileDAO.findByName(userid); // Doing anything with the object after this?
        updateProfileModel = (UpdateProfileBean) result.get(0); // if multiple found, just pick the 1st one. If none?
        if (updateProfileModel != null) 
            return "update.xhtml?faces-redirect=true"; // navigate to "update2.xhtml"
        else
            return "error.xhtml"; 
    }
    
    public void updateThis() {
        UpdateProfileDAO aUpdateProfileDAO = new UpdateProfileDAOImpl();    // Creating a new object each time.
        int status = aUpdateProfileDAO.updateProfile(updateProfileModel); // Doing anything with the object after this?
        if (status != 0) {
            updateStatus = "Record updated successfully ...";
        } else {
            updateStatus = "Record update failed!";
        }

    }
}
