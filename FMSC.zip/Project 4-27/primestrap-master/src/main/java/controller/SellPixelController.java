package controller;

import dao.GenerateImageDAOImpl;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import model.PixelBean;

import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

@ManagedBean(name = "imageBean")
@RequestScoped
public class SellPixelController implements Serializable {

    /**
     * @author Mike
     * 
     */
    private static final long serialVersionUID = 1L;
    private PixelBean pixelBean;

    public StreamedContent getImage(ArrayList<PixelBean> pixelsData) throws IOException {
    	
        FacesContext context = FacesContext.getCurrentInstance();
        System.out.println(pixelsData.size());
        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        BufferedImage image = ImageIO.read(context.getExternalContext()
                .getResourceAsStream("/resources/images/1.png"));
        int width = image.getWidth();
        int height = image.getHeight();

        
        int[] imagePixels = image.getRGB(0, 0, width, height, null, 0, width);

      
        int[] newMaskPixels = image.getRGB(0, 0, width, height, null, 0, width);
        
        
        Color myBlack = new Color(0, 0, 0); // Color white
        int rgb = myBlack.getRGB();

        try {
            BufferedImage img = null;
            try {
                img = ImageIO.read(context.getExternalContext()
                        .getResourceAsStream("/resources/images/2.png"));
            } catch (IOException e) {
            }
            for (int i = 0; i < pixelsData.size(); i++) {
                for (int j = pixelsData.get(i).getCoord_x1(); j < pixelsData.get(i).getCoord_y1(); j++) {
                    for (int k = pixelsData.get(i).getCoord_x2(); k < pixelsData.get(i).getCoord_y2(); k++) {
                        img.setRGB(j, k, rgb);
                    }
                }
            }
            // retrieve image
            ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance()
                    .getExternalContext().getContext();
            
            String realPath = ctx.getRealPath("/");
            String fileName1 = realPath + "resources\\images\\saved.png";
            //System.out.println(fileName1); ///prints out the real path
            File outputfile = new File(fileName1);
            ImageIO.write(img, "png", outputfile);

            newMaskPixels = img.getRGB(0, 0, width, height, null, 0, width);
           
            for (int i = 0; i < newMaskPixels.length; i++) {
                int color = newMaskPixels[i];//& 0x00FFFFFF; // Mask preexisting alpha
                int alpha = imagePixels[i]; // Shift blue to alpha
                newMaskPixels[i] = alpha | color;
            }
  
            img.setRGB(0, 0, width, height, newMaskPixels, 0, width);
            
            
           

            String fileName = realPath + "/resources/images/saved.png";
            ImageIO.write(img, "png", new File(fileName));

        
        } catch (IOException e) {
        }

    	
        return new DefaultStreamedContent(new ByteArrayInputStream(
                bos.toByteArray()), "image/png");
    	

    }

    public String imageMap(ArrayList<PixelBean> pixelsData) throws IOException {

        
        getImage(pixelsData);
        String linkVar = "\"./resources/images/saved.png\"";
        String imgString = "<img src=" + linkVar + " ismap=\"true\" usemap=\"#pixelmap\">";
        String mapString = "<map name=\"pixelmap\">";
        String mapBuild = "";
        if(pixelsData.size()>0) {
        for (int i = 0; i < pixelsData.size(); i++) {
            int x1 = pixelsData.get(i).getCoord_x1();
            int x2 = pixelsData.get(i).getCoord_x2();
            int y1 = pixelsData.get(i).getCoord_y1();
            int y2 = pixelsData.get(i).getCoord_y2();
            String title = pixelsData.get(i).getTitle();
            String website = pixelsData.get(i).getWebsite();
            mapBuild += "<area shape=\"rect\" coords=\"" +  x1 + "," + x2 + "," + y1 + "," + y2 + "\" " + 
                     "href=\"http://"  +  website + "\" " +
                    "title=\"" + title + "\" >" + "\n";

        }
        }
        mapBuild += " </map>";
        System.out.println("Executing imagemap code");
        String webpage
                = imgString + "\n"
                + mapString + "\n"
                + mapBuild;

        
        return webpage;
    }

    public String createPixelsView() throws IOException {
        GenerateImageDAOImpl aGenerateImageDAO = new GenerateImageDAOImpl();
        ArrayList result = aGenerateImageDAO.createView();
        String response = imageMap(result);

        return response;

    }
}
