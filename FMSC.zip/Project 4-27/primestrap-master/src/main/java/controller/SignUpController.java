/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.SignUpDAO;
import dao.SignUpDAOImpl;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import model.SignUpBean;

/**
 *
 * @author it3530105
 */
@ManagedBean
@SessionScoped
public class SignUpController {
     private SignUpBean signupModel;
     private String response;

    /**
     * Creates a new instance of LoginController
     */
    public SignUpController() {
        signupModel = new SignUpBean();
    }
    
    public String getResponse() {
        String resultStr = "";
        resultStr += "Hello " + getSignupModel().getFname() + " " + getSignupModel().getLname() + "<br/>";
        resultStr += "Your userid is: " + getSignupModel().getUserid() + "<br/>";
        resultStr += "Your emailid is: " + getSignupModel().getEmail() + "<br/>";
        resultStr += "Your security question is: " + getSignupModel().getSec_question() + "<br/>";
        resultStr += "Your security question answer is: " + getSignupModel().getSec_answer() + "<br/>";
        
        response = resultStr;
        return response;
    }

    
    public void setResponse(String response) {
        this.response = response;
    }

    public String createProfile() {
        SignUpDAO aSignUpDAO = new SignUpDAOImpl();    // Creating a new object each time.
        int rowCount = aSignUpDAO.createProfile(getSignupModel()); // Doing anything with the object after this?
        
        if (rowCount == 1)
            return "echo.xhtml?faces-redirect=true"; // navigate to "response.xhtml"
         else   
            return ""; 
    }

    /**
     * @return the signupModel
     */
    public SignUpBean getSignupModel() {
        return signupModel;
    }

    /**
     * @param signupModel the signupModel to set
     */
    public void setSignupModel(SignUpBean signupModel) {
        this.signupModel = signupModel;
    }
}

  
