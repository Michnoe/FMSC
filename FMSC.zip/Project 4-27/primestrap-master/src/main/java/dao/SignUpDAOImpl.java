/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import model.SignUpBean;

/**
 *
 * Author -> Michael Noe This class is for DAO Implementation This code
 * contains login for handling O'Connor error.
 */
public class SignUpDAOImpl implements SignUpDAO {

    @Override
    public int createProfile(SignUpBean aLogin) {
        int rowCount = 0;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
            System.exit(0);
        }

        try {
            //String myDB = "jdbc:mysql://project353.cvzlvgeblu4c.us-east-1.rds.amazonaws.com:3306/Project353";
        	 String filename = "C:/Users/super/Documents/Project353.accdb";//use the name of your database!
             
             String myDB = "jdbc:ucanaccess://"+ filename +";memory=false";
            Connection DBConn = DriverManager.getConnection(myDB, "", "");

            String insertString;
            Statement stmt = DBConn.createStatement();
            insertString = "INSERT INTO Users VALUES ('"
                    + aLogin.getFname()
                    + "','" + aLogin.getLname()
                    + "','" + aLogin.getUserid()
                    + "','" + aLogin.getPasswd()
                    + "','" + aLogin.getEmail()
                    + "','" + aLogin.getSec_question()
                    + "','" + aLogin.getSec_answer()
                    + "')";

            rowCount = stmt.executeUpdate(insertString);
            System.out.println("insert string =" + insertString);
            DBConn.close();
        } catch (SQLIntegrityConstraintViolationException sqle) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "UserID already exist.", "Error:"));

            FacesContext.getCurrentInstance().getPartialViewContext().getRenderIds()
                    .add("globalMessage");
            rowCount =2;

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        if (rowCount == 1) {
            rowCount = createLogin(aLogin);
            JavaMailApp jmp = new JavaMailApp(aLogin.getEmail(), aLogin.getFname(), aLogin.getLname(), aLogin.getUserid(), aLogin.getSec_question(), aLogin.getSec_answer());
        }

        // if insert is successful, rowCount will be set to 1 (1 row inserted successfully). Else, insert failed.
        return rowCount;

    }

    public int createLogin(SignUpBean aLogin) {
        int rowCount = 0;
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
            System.exit(0);
        }

        try {
            //String myDB = "jdbc:mysql://project353.cvzlvgeblu4c.us-east-1.rds.amazonaws.com:3306/Project353";
        	 String filename = "C:/Users/super/Documents/Project353.accdb";//use the name of your database!
             
             String myDB = "jdbc:ucanaccess://"+ filename +";memory=false";
            Connection DBConn = DriverManager.getConnection(myDB, "", "");

            String insertString;
            Statement stmt = DBConn.createStatement();
            insertString = "INSERT INTO LoginInfo VALUES ('"
                    + aLogin.getUserid()
                    + "','" + aLogin.getPasswd()
                    + "')";

            rowCount = stmt.executeUpdate(insertString);
            System.out.println("insert string =" + insertString);
            DBConn.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return rowCount;
    }
}
