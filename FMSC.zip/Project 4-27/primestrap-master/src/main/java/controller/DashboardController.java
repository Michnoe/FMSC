/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.GenerateImageDAOImpl;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.faces.bean.RequestScoped;
import javax.annotation.PostConstruct;
import java.io.Serializable;
import java.util.ArrayList;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import model.PixelBean;
import org.primefaces.event.ItemSelectEvent;
 
import org.primefaces.model.chart.PieChartModel;
 
/**
 *
 * @author Mike
 */
 /*Some of the code here is not used. 
  * I wanted  to create some demographic stats of the people who donated
  * and ultimateLY decided against having it implemented
  * */
@ManagedBean
@RequestScoped
public class DashboardController implements Serializable {
 
    //private BarChartModel barModel  NOT IMPLEMENTED;
    private PieChartModel pieModel1;
    private int sold_pixels;
    @PostConstruct
    public void init() {
        //createBarModels();
        createPieModels();
    }
 
//    public BarChartModel getBarModel() {
//        return barModel;
//    }
     
    public PieChartModel getPieModel1() {
        return pieModel1;
    }
    
    
     private void createPieModels() {
        createPieModel1();
    }
     private int retrieveSoldPixels(){
         GenerateImageDAOImpl aGenerateImageDAO = new GenerateImageDAOImpl();
         ArrayList<PixelBean> result = aGenerateImageDAO.createView();
         int sold_pixels_sum = 0;
         for (int i = 0; i < result.size(); i++) {
             sold_pixels_sum += result.get(i).getArea();
         
         }
         return sold_pixels_sum;
     } 
    private int getSizeOfImage() {
     FacesContext context = FacesContext.getCurrentInstance();
        int width = 0;
        int height = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try{
        BufferedImage image = ImageIO.read(context.getExternalContext()
                .getResourceAsStream("/resources/images/saved.png"));
        width = image.getWidth();
        height = image.getHeight();
        }
        catch(IOException ioe)
        {
            System.err.println("IOException generated");
        }
        
    return width*height;
    }
    private void createPieModel1() {
        pieModel1 = new PieChartModel();
        
        int sold_pixels_sum = retrieveSoldPixels();
        sold_pixels = sold_pixels_sum;
        System.out.println("sold_pixels_sum: "+sold_pixels_sum);
        int sizeOfImage = getSizeOfImage();
        System.out.println("sold_pixels_sum: "+sold_pixels_sum+ " sizeofimage: "+sizeOfImage);
        int sold_percentage = (sold_pixels_sum * 100)/ sizeOfImage;
        int unsold_percentage = 100 - sold_percentage; 
        System.out.println("Sold pixels" + sold_percentage + " Unsold Pixels: "+ unsold_percentage);
        pieModel1.set("Pixels Sold", sold_percentage);
        pieModel1.set("Unsold", unsold_percentage);
        
        pieModel1.setShowDataLabels(true);
        pieModel1.setTitle("Pie chart showing percentage of pixels sold");
        pieModel1.setLegendPosition("w");
    }
 
    public void itemSelect(ItemSelectEvent event) {
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Item selected",
                        "Item Index: " + event.getItemIndex() + ", Series Index:" + event.getSeriesIndex());
         
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }
// 
//    private void createBarModels() {
//        createBarModel();
//    }
//     
//    private void createBarModel() {
//        barModel = initBarModel();
//         
//        barModel.setTitle("Bar Chart");
//        barModel.setLegendPosition("ne");
//         
//        Axis xAxis = barModel.getAxis(AxisType.X);
//        xAxis.setLabel("Gender");
//         
//        Axis yAxis = barModel.getAxis(AxisType.Y);
//        yAxis.setLabel("Births");
//        yAxis.setMin(0);
//        yAxis.setMax(200);
//    }
//     //JSF Page
//    <p:chart type="bar" model="#{chartView.barModel}" style="width:400px;height:300px">
//            <p:ajax event="itemSelect" listener="#{chartView.itemSelect}" update="growl" />
//        </p:chart>  
//    private BarChartModel initBarModel() {
//        BarChartModel model = new BarChartModel();
// 
//        ChartSeries boys = new ChartSeries();
//        boys.setLabel("Boys");
//        boys.set("2004", 120);
//        boys.set("2005", 100);
//        boys.set("2006", 44);
//        boys.set("2007", 150);
//        boys.set("2008", 25);
// 
//        ChartSeries girls = new ChartSeries();
//        girls.setLabel("Girls");
//        girls.set("2004", 52);
//        girls.set("2005", 60);
//        girls.set("2006", 110);
//        girls.set("2007", 135);
//        girls.set("2008", 120);
// 
//        model.addSeries(boys);
//        model.addSeries(girls);
//         
//        return model;
//    }

    /**
     * @return the sold_pixels
     */
    public int getSold_pixels() {
        return sold_pixels;
    }

    /**
     * @param sold_pixels the sold_pixels to set
     */
    public void setSold_pixels(int sold_pixels) {
        this.sold_pixels = sold_pixels;
    }
 
   
}