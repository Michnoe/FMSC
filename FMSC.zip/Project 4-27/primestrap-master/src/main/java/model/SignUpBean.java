/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author it3530105
 */
public class SignUpBean {
    
    //default constructor
    public SignUpBean(){
    }
    
    //parametrized constructor
    public SignUpBean(String fname, String lname, String userid, String passwd, String email, String sec_question, String sec_answer){
        this.fname  =    fname;
        this.lname  =    lname;
        this.userid =    userid;
        this.passwd =    passwd; 
        this.email  =    email;
        this.sec_question = sec_question;
        this.sec_answer = sec_answer;
    }
   
    //refers to the form elements
    private String fname;
    private String lname;
    private String userid;
    private String passwd;
    private String email;
    private String sec_question;
    private String sec_answer;

    /**
     * @return the fname
     */
    public String getFname() {
        return fname;
    }

    /**
     * @param fname the fname to set
     */
    public void setFname(String fname) {
        this.fname = fname;
    }

    /**
     * @return the lname
     */
    public String getLname() {
        return lname;
    }

    /**
     * @param lname the lname to set
     */
    public void setLname(String lname) {
        this.lname = lname;
    }

    /**
     * @return the userid
     */
    public String getUserid() {
        return userid;
    }

    /**
     * @param userid the userid to set
     */
    public void setUserid(String userid) {
        this.userid = userid;
    }

    /**
     * @return the passwd
     */
    public String getPasswd() {
        return passwd;
    }

    /**
     * @param passwd the passwd to set
     */
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the sec_question
     */
    public String getSec_question() {
        return sec_question;
    }

    /**
     * @param sec_question the sec_question to set
     */
    public void setSec_question(String sec_question) {
        this.sec_question = sec_question;
    }

    /**
     * @return the sec_answer
     */
    public String getSec_answer() {
        return sec_answer;
    }

    /**
     * @param sec_answer the sec_answer to set
     */
    public void setSec_answer(String sec_answer) {
        this.sec_answer = sec_answer;
    }

 
}
