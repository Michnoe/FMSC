/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.faces.context.FacesContext;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.ServletContext;

import model.LoginBean;
import model.ResetPasswordBean;
import java.math.BigInteger;



/**
 *
 * @author it3530105
 */
public class ResetPasswordDAOImpl {
	// Secure Random alpha numeric string generation
	// http://stackoverflow.com/questions/41107/how-to-generate-a-random-alpha-numeric-string
	
	static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	static SecureRandom rnd = new SecureRandom();

	String randomString( int len ){
	   StringBuilder sb = new StringBuilder( len );
	   for( int i = 0; i < len; i++ ) 
	      sb.append( AB.charAt( rnd.nextInt(AB.length()) ) );
	   return sb.toString();
	}
   
    public boolean checkEmail(ResetPasswordBean aResetPasswordBean) {
      
          //catch if derby ins't included
          try {
              Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
          } catch (ClassNotFoundException e) {
              System.err.println(e.getMessage());
              System.exit(0);
          }
          boolean found = false;
          try {
        	  
              //String myDB = "jdbc:mysql://project353.cvzlvgeblu4c.us-east-1.rds.amazonaws.com:3306/Project353";
        	  
              String filename = "C:/Users/super/Documents/Project353.accdb";//use the name of your database!
              
              String myDB = "jdbc:ucanaccess://"+ filename +";memory=false";
        	  
              Connection DBConn = DriverManager.getConnection(myDB, "", "");
              PreparedStatement pstmt = DBConn.prepareStatement("SELECT * FROM Users WHERE EMAIL = ?");
              String username;
              pstmt.setString( 1, aResetPasswordBean.getEmail());
              ResultSet rs = pstmt.executeQuery();
              //found value
              
              if (rs.next()) {
                  found = true;
                  username =   rs.getString("USERID");
                  aResetPasswordBean.setUsername(username);
              }
              //close connection
              //System.out.println("username = "+ aResetPasswordBean.getUsername());
              pstmt.close();
              DBConn.close();
          } catch (SQLException e) {
              System.err.println(e.getMessage());
          }
          
          return found;
      }
    public int setPassword(ResetPasswordBean aResetPasswordBean) {
    	
    	String generatedPassword = randomString(15);	  
    	aResetPasswordBean.setGeneratedPassword(generatedPassword);	
    	
    	Connection DBConn = null;
        //catch if derby ins't included
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        } catch (ClassNotFoundException e) {
            System.err.println(e.getMessage());
            System.exit(0);
        }
        int rowCount = 0;
        try {
           
            //String myDB = "jdbc:mysql://project353.cvzlvgeblu4c.us-east-1.rds.amazonaws.com:3306/Project353";
        	String filename = "C:/Users/super/Documents/Project353.accdb";//use the name of your database!
            
            String myDB = "jdbc:ucanaccess://"+ filename +";memory=false";
            DBConn = DriverManager.getConnection(myDB, "", "");

            String updateString;
            Statement stmt = DBConn.createStatement();

            // SQL UPDATE Syntax [http://www.w3schools.com]:
            // UPDATE table_name
            // SET column1=value, column2=value2,...
            // WHERE some_column=some_value
            // Note: Notice the WHERE clause in the UPDATE syntax. The WHERE clause specifies which record or records that should be updated. If you omit the WHERE clause, all records will be updated!
            
            //fname, lname, userid, password, email, sec_question, sec_answer
            updateString = "UPDATE LoginInfo SET "
                    + "password = '" + aResetPasswordBean.getGeneratedPassword()+  "' "
                    + "WHERE userid = '" + aResetPasswordBean.getUsername() + "'";
            rowCount = stmt.executeUpdate(updateString);
            //System.out.println("updateString =" + updateString);
            
            
            
            String updateString1;
            Statement stmt1 = DBConn.createStatement();

            // SQL UPDATE Syntax [http://www.w3schools.com]:
            // UPDATE table_name
            // SET column1=value, column2=value2,...
            // WHERE some_column=some_value
            // Note: Notice the WHERE clause in the UPDATE syntax. The WHERE clause specifies which record or records that should be updated. If you omit the WHERE clause, all records will be updated!
            
            //fname, lname, userid, password, email, sec_question, sec_answer
            updateString1 = "UPDATE Users SET "
                    + "password = '" + aResetPasswordBean.getGeneratedPassword()+  "' "
                    + "WHERE userid = '" + aResetPasswordBean.getUsername() + "'";
            rowCount = stmt1.executeUpdate(updateString1);
            //System.out.println("updateString =" + updateString1);
            DBConn.close();
            
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        
        return rowCount;
    }
    public void sendEmail(ResetPasswordBean aResetPasswordBean){  	 
   	 	String str;
        // Recipient's email ID needs to be mentioned.
        String to = aResetPasswordBean.getEmail();

        // Sender's email ID needs to be mentioned
        String from = "manoe@ilstu.edu";

        // Assuming you are sending email from this host
        String host = "outlook.office365.com";

        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server
        properties.setProperty("mail.smtp.host", host);
        properties.setProperty("mail.smtp.starttls.enable", "true");
         properties.setProperty("mail.smtp.auth", "true");
         properties.setProperty("mail.smtp.port", "587");
        // Get the default Session object.
        Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
        protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication("manoe@ilstu.edu", "UiD808987608");
        
           }
});
        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session); 

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            message.setRecipients(Message.RecipientType.TO,
                    new InternetAddress(to).parse(to));

            // Set Subject: header field
            message.setSubject("Your password");
            
            
            // This mail has 2 part, the BODY and the embedded image
            MimeMultipart multipart = new MimeMultipart("related");
            
            // first part (the html)
            BodyPart messageBodyPart = new MimeBodyPart();
            str = "You have requested us to retrieve your password for you.<br/>";
            str += "</br>Registered Userid is: " + aResetPasswordBean.getUsername() + "<br/><br/>";
            str += "Your resetted Password is:" + aResetPasswordBean.getGeneratedPassword() +"</br></br>";
            str += "Thanks,<br/>FMSC Technical Team<br/>Feed My Starving Children<br/>";
            str += "<img src=\"cid:image\">";
            messageBodyPart.setContent(str, "text/html");

            
             multipart.addBodyPart(messageBodyPart);
             
             messageBodyPart = new MimeBodyPart();
            // Send the actual HTML message, as big as you like
            
            //Code for handling the nullpointerexception for image
            ServletContext ctx = (ServletContext) FacesContext.getCurrentInstance()
                    .getExternalContext().getContext();
            String realPath = ctx.getRealPath("/");

            String fileName = realPath + "/resources/images/fmsclogo.jpg";
             DataSource fds = new FileDataSource(fileName);
            

            messageBodyPart.setDataHandler(new DataHandler(fds));
            messageBodyPart.setHeader("Content-ID", "<image>");

            // add image to the multipart
            multipart.addBodyPart(messageBodyPart);

            // put everything together
            message.setContent(multipart);

            // Send message
            Transport.send(message);
            
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }
            
        }
        
    }

 