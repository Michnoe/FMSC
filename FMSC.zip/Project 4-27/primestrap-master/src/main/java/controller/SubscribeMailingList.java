package controller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.faces.bean.ManagedBean;
import model.EmailBean;


/**
 *
 * @author super
 */
@ManagedBean(name = "Mail")

public class SubscribeMailingList {

  public int createProfile(EmailBean theModel) {
    try {
      Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    } catch (ClassNotFoundException e) {
      System.err.println(e.getMessage());
      System.exit(0);
    }

    int rowCount = 0;
    try {
      //String myDB = "jdbc:mysql://project353.cvzlvgeblu4c.us-east-1.rds.amazonaws.com:3306/Project353";
      String filename = "C:/Users/super/Documents/Project353.accdb";
      String myDB = "jdbc:ucanaccess://"+ filename +";memory=false\";";
      Connection DBConn = DriverManager.getConnection(myDB, "", "");

      String insertString;
      Statement stmt = DBConn.createStatement();
      insertString = "INSERT INTO MAILING VALUES ('"
              + theModel.getMail()
              
              + "')";

      rowCount = stmt.executeUpdate(insertString);
      System.out.println("insert string =" + insertString);
      DBConn.close();
    } catch (SQLException e) {
      System.err.println(e.getMessage());
    }

    // if insert is successful, rowCount will be set to 1 (1 row inserted successfully). Else, insert failed.
    return rowCount;
  }

  public int removeProfile(EmailBean theModel) {
    Connection DBConn = null;
    try {
      Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    } catch (ClassNotFoundException e) {
      System.err.println(e.getMessage());
      System.exit(0);
    }
    int rowCount = 0;
    try {
      //String myDB = "jdbc:mysql://project353.cvzlvgeblu4c.us-east-1.rds.amazonaws.com:3306/Project353";
      String filename = "C:/Users/super/Documents/Project353.accdb";
      String myDB = "jdbc:ucanaccess://"+ filename +";memory=false\";";	
      DBConn = DriverManager.getConnection(myDB, "", "");

      String updateString;
      Statement stmt = DBConn.createStatement();
      System.out.println("Model Email:---------" + theModel.getMail());

      updateString = "DELETE FROM MAILING WHERE email='" + theModel.getMail() + "'";

      rowCount = stmt.executeUpdate(updateString);
      System.out.println("updateString =" + updateString);
      DBConn.close();
    } catch (SQLException e) {
      System.err.println(e.getMessage());
    }

    return rowCount;
  }

  static ArrayList<String> removeDuplicates(ArrayList<EmailBean> list) {

    // Store unique items in result.
    ArrayList<String> result = new ArrayList<>();
    ArrayList<String> emails = new ArrayList<>();

    for (EmailBean item : list) {
      emails.add(item.getMail());
    }

    // Record encountered Strings in HashSet.
    HashSet<String> set = new HashSet<>();

    // Loop over argument list.
    for (String item : emails) {

      // If String is not in set, add it to the list and the set.
      if (!set.contains(item)) {
        result.add(item);
        System.out.println(item);
        set.add(item);
      }
    }
    return result;
  }

}
